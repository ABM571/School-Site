const SH={rep:'بلاغات الصيانة والمرافق',call:'الاستئذان والنداء الرقمي',sug:'صوت الطالبة والاقتراحات',ts:'الخدمات الإدارية والتحضير',plan:'المخطط الدراسي',guid:'الإرشاد الطلابي (سري)',att:'الحضور والغياب',ros:'قوائم الفصول',cfg:'الإعدادات'};
const HD={rep:['رقم البلاغ','نوع الطلب','الممر','الفصل/المكان','الشرح','الاسم','الأولوية','الحالة','التاريخ'],
call:['رقم النداء','الاسم','الفصل','الجهة المستدعية','نوع الطلب','الحالة','الوقت'],
sug:['رقم الاقتراح','الاسم','النوع','الفكرة/المقترح','الحالة','التاريخ'],
ts:['التاريخ','المعلمة','نوع الخدمة','التفاصيل','حالة الاعتماد'],
plan:['التاريخ','النوع','الفصل','العنوان','التفاصيل','أضافها'],
att:['التاريخ','الفصل','الحصة','المعلمة','حاضرات','غائبات','متأخرات','بعذر','الوقت'],
ros:['الفصل','اسم الطالبة'],
guid:['الرمز','النوع','الاسم','الفصل','الرسالة','الأولوية','الحالة','رد المرشدة','التاريخ'],
cfg:['JSON']};
const STCOL={rep:8,sug:5,ts:5};
function doGet(){return HtmlService.createHtmlOutputFromFile('Index').setTitle('منصة الخدمات المدرسية')
 .addMetaTag('viewport','width=device-width, initial-scale=1').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);}
function sh_(k){const ss=SpreadsheetApp.getActive();let s=ss.getSheetByName(SH[k]);
 if(!s){s=ss.insertSheet(SH[k]);s.appendRow(HD[k]);s.setRightToLeft(true);s.setFrozenRows(1);s.getRange(1,1,1,HD[k].length).setFontWeight('bold').setBackground('#ede5fb');
  if(k=='plan'||k=='att')s.getRange('A:A').setNumberFormat('yyyy-mm-dd');else if(k=='guid'){s.getRange('A:A').setNumberFormat('@');s.getRange('G2:G').setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(['جديد','قيد المتابعة','تمت المتابعة']).build());}else if(k!='ts'&&k!='ros'&&k!='cfg')s.getRange('A:A').setNumberFormat('0000');}return s;}
function setup(){Object.keys(SH).forEach(sh_);}
function now_(){return Utilities.formatDate(new Date(),'Asia/Riyadh','yyyy-MM-dd HH:mm');}
function pin_(p,a){const P=PropertiesService.getScriptProperties(),A=P.getProperty('PIN')||'1234',S=P.getProperty('SPIN')||A;p=String(p);if(p===A)return 'a';if(!a&&p===S)return 's';throw new Error('pin');}
function login(p){return pin_(p);}
function nid_(k){const l=LockService.getScriptLock();l.waitLock(10000);try{const P=PropertiesService.getScriptProperties();
 const key=k=='call'?'cseq':'seq';const n=+(P.getProperty(key)||(k=='call'?0:141))+1;P.setProperty(key,n);return n;}finally{l.releaseLock();}}
function addReport(o){if(!o.name||!o.name.trim()||!o.desc||!o.desc.trim())throw new Error('missing');
 const prob=o.type=='أبلغ عن مشكلة',id=nid_('rep');
 if(prob)sh_('rep').appendRow([id,o.type,o.corr,o.place,o.desc,o.name,'عالية','جديد',now_()]);
 else sh_('sug').appendRow([id,o.name,o.type,o.desc+' ('+o.corr+' / '+o.place+')','جديد',now_()]);
 return ('000'+id).slice(-4);}
function track(id){for(const k of ['rep','sug']){const d=sh_(k).getDataRange().getDisplayValues();
 for(let i=1;i<d.length;i++)if(Number(d[i][0])==Number(id))return k=='rep'?{id:d[i][0],type:d[i][1],where:d[i][2]+' / '+d[i][3],desc:d[i][4],st:d[i][7],date:d[i][8]}:{id:d[i][0],type:d[i][2],where:'',desc:d[i][3],st:d[i][4],date:d[i][5]};}
 return null;}
function addTserv(p,o){pin_(p);if(!o.name||!o.name.trim())throw new Error('missing');sh_('ts').appendRow([now_(),o.name,o.type,o.det,'بانتظار الاعتماد']);}
function pub(p){pin_(p);const d=sh_('call').getDataRange().getDisplayValues();
 return d.slice(1).filter(r=>r[5]=='نشط').slice(-15).map(r=>({id:+r[0],name:r[1],cls:r[2],type:r[4]}));}
function addCall(p,o){pin_(p,1);if(!o.name||!o.name.trim())throw new Error('missing');
 sh_('call').appendRow([nid_('call'),o.name,o.cls,'الإدارة',o.type,'نشط',now_()]);}
function endCall(p,id){pin_(p,1);const s=sh_('call'),d=s.getDataRange().getValues();
 for(let i=1;i<d.length;i++)if(Number(d[i][0])==Number(id))s.getRange(i+1,6).setValue('تم');}
function admin(p){pin_(p,1);const o={};['rep','call','sug','ts','att','plan'].forEach(k=>o[k]=sh_(k).getDataRange().getDisplayValues().slice(1).reverse());return o;}
function setStatus(p,k,key,v){pin_(p,1);const s=sh_(k);
 if(k=='ts'){const d=s.getDataRange().getDisplayValues();for(let i=1;i<d.length;i++)if(d[i][0]+'|'+d[i][1]==key)s.getRange(i+1,5).setValue(v);return;}
 const d=s.getDataRange().getValues();for(let i=1;i<d.length;i++)if(Number(d[i][0])==Number(key))s.getRange(i+1,STCOL[k]).setValue(v);}

function addPlan(p,o){pin_(p);if(!o.by||!o.by.trim()||!o.title||!o.date)throw new Error('missing');
 sh_('plan').appendRow([o.date,o.type,o.cls||'الكل',o.title,o.det||'',o.by]);}
function getPlan(cls){const t=Utilities.formatDate(new Date(),'Asia/Riyadh','yyyy-MM-dd');
 return sh_('plan').getDataRange().getDisplayValues().slice(1).filter(r=>r[0]>=t&&(!cls||cls=='الكل'||r[2]=='الكل'||r[2]==cls))
 .sort((a,b)=>a[0]<b[0]?-1:1).slice(0,60).map(r=>({d:r[0],t:r[1],c:r[2],h:r[3],x:r[4],b:r[5]}));}
function addGuid(o){if(!o.type||!o.msg||!o.msg.trim())throw new Error('missing');
 const anon=o.type=='بلاغ مجهول';if(!anon&&o.type!='أحتاج أتكلم'&&!(o.name&&o.name.trim()))throw new Error('missing');
 const code=Utilities.getUuid().replace(/-/g,'').slice(0,6).toUpperCase();
 sh_('guid').appendRow([code,o.type,anon?'—':(o.name||'—'),anon?'—':(o.cls||'—'),o.msg,o.urgent?'عاجل':'عادي','جديد','',now_()]);return code;}
function trackGuid(code){const d=sh_('guid').getDataRange().getDisplayValues(),k=String(code).trim().toUpperCase();
 for(let i=1;i<d.length;i++)if(d[i][0]==k)return{st:d[i][6],reply:d[i][7],date:d[i][8]};return null;}

function today_(){return Utilities.formatDate(new Date(),'Asia/Riyadh','yyyy-MM-dd');}
function getRoster(p,cls){pin_(p);return sh_('ros').getDataRange().getDisplayValues().slice(1).filter(r=>r[0]==cls).map(r=>r[1]);}
function setRoster(p,cls,names){pin_(p);const s=sh_('ros'),d=s.getDataRange().getValues();
 for(let i=d.length-1;i>=1;i--)if(d[i][0]==cls)s.deleteRow(i+1);
 const r=names.filter(n=>n&&n.trim()).map(n=>[cls,n.trim()]);if(r.length)s.getRange(s.getLastRow()+1,1,r.length,2).setValues(r);}
function saveAtt(p,o){pin_(p);if(!o.by||!o.by.trim())throw new Error('missing');const s=sh_('att'),t=today_(),d=s.getDataRange().getDisplayValues(),j=a=>(a||[]).join('، ');
 const row=[t,o.cls,String(o.per),o.by,j(o.p),j(o.a),j(o.l),j(o.e),now_()];
 for(let i=1;i<d.length;i++)if(d[i][0]==t&&d[i][1]==o.cls&&d[i][2]==String(o.per)){s.getRange(i+1,1,1,row.length).setValues([row]);return;}
 s.appendRow(row);}
function loadAtt(p,cls,per){pin_(p);const t=today_(),d=sh_('att').getDataRange().getDisplayValues(),sp=x=>x?x.split('، '):[];
 for(let i=1;i<d.length;i++)if(d[i][0]==t&&d[i][1]==cls&&d[i][2]==String(per))return{a:sp(d[i][5]),l:sp(d[i][6]),e:sp(d[i][7])};return null;}
function attStat(p){pin_(p);const t=today_(),o={};sh_('att').getDataRange().getDisplayValues().slice(1).filter(r=>r[0]==t).forEach(r=>{o[r[1]]=(o[r[1]]||0)+1});return o;}

/* ===== إعدادات الإدارة ===== */
const DEF={school:'اسم المدرسة',l1:'المملكة العربية السعودية  •  وزارة التعليم',edu:'إدارة التعليم بالمنطقة الشرقية',sla:'٣ أيام عمل',periods:7,
 groups:[{n:'🟢 ممر A',t:'c',r:['فصل 1/1','فصل 1/2','فصل 1/3','فصل 2/1','فصل 2/2','فصل 2/3'],x:['ساحة الممر']},
  {n:'🔵 ممر B',t:'c',r:['فصل 3/1','فصل 3/2','فصل 3/3','فصل 4/1','فصل 4/2','فصل 4/3'],x:['ساحة الممر']},
  {n:'الساحة الخارجية',t:'p',r:['الطابور الصباحي','الملعب','البوابة'],x:[]},
  {n:'المرافق العامة',t:'p',r:['المقصف المدرسي','دورات المياه','المصلى','مصادر التعلم','المعمل'],x:[]}],
 ann:[['تعميم','فتح باب تقديم البلاغات والاقتراحات عبر البوابة، ويُرجى حفظ رقم المتابعة','اليوم'],['نشاط','مسابقة أجمل ممر — شاركي بفكرتك من خلال خدمة صوت الطالبة','هذا الأسبوع'],['تنبيه','تُرسل نداءات الإدارة إلى شاشة الفصل الذكية مباشرة','دائماً']],
 ts:['استئذان','طلب غطاء / انتظار','حجز المعمل','حجز غرفة مصادر التعلم','حجز المسرح','حجز جهاز عرض','رصد غياب الفصل'],
 callTypes:['مراجعة الإدارة','استئذان مبكر','ولي الأمر بالانتظار']};
const T_=x=>String(x==null?'':x).replace(/['"\\<>`]/g,'').trim();
const L_=a=>[...new Set((a||[]).map(T_).filter(Boolean))];
function cfg_(){const C=CacheService.getScriptCache(),h=C.get('cfg');if(h)return JSON.parse(h);
 let c=DEF;try{const v=sh_('cfg').getRange('A2').getValue();if(v)c=Object.assign({},DEF,JSON.parse(v));}catch(e){}
 try{C.put('cfg',JSON.stringify(c),600);}catch(e){}return c;}
function getConfig(){return cfg_();}
function renameClass_(a,b){[['ros',1],['att',2],['plan',3],['call',3]].forEach(([k,c])=>{const s=sh_(k),n=s.getLastRow()-1;if(n<1)return;
 const g=s.getRange(2,c,n,1),v=g.getValues();let ch=0;v.forEach(r=>{if(r[0]==a){r[0]=b;ch=1;}});if(ch){g.setNumberFormat('@');g.setValues(v);}});}
function saveConfig(p,c,rn){pin_(p,1);
 const o={school:T_(c.school),l1:T_(c.l1),edu:T_(c.edu),sla:T_(c.sla),periods:Math.min(12,Math.max(1,+c.periods||7)),
  groups:(c.groups||[]).map(g=>({n:T_(g.n),t:g.t=='c'?'c':'p',r:L_(g.r),x:L_(g.x)})).filter(g=>g.n),
  ann:(c.ann||[]).filter(a=>a&&T_(a[1])).map(a=>[T_(a[0])||'تعميم',T_(a[1]),T_(a[2])]),
  ts:L_(c.ts),callTypes:L_(c.callTypes)};
 if(!o.school||!o.groups.length||!o.ts.length||!o.callTypes.length)throw new Error('bad');
 (rn||[]).forEach(x=>{const a=T_(x[0]),b=T_(x[1]);if(a&&b&&a!=b)renameClass_(a,b);});
 sh_('cfg').getRange('A2').setNumberFormat('@').setValue(JSON.stringify(o));
 CacheService.getScriptCache().remove('cfg');return o;}
function changePin(p,n,l){pin_(p,1);n=String(n).trim();if(n.length<4)throw new Error('short');PropertiesService.getScriptProperties().setProperty(l=='s'?'SPIN':'PIN',n);}
function delRow(p,k,key){pin_(p,1);if(['rep','sug','call','ts','plan'].indexOf(k)<0)throw new Error('bad');
 const s=sh_(k),d=s.getDataRange().getDisplayValues();
 for(let i=d.length-1;i>=1;i--){const r=d[i],m=k=='ts'?r[0]+'|'+r[1]==key:k=='plan'?r[0]+'|'+r[3]==key:Number(r[0])==Number(key);if(m){s.deleteRow(i+1);return;}}}
